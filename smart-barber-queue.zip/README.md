# Smart Barber Queue System

GitHub-style project.